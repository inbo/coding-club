#' A set of ingredients
#'
#' A basic set of ingredients for making tasty doughs.
#'
#' @format A data frame with 4 rows and 2 columns:
#' - `grains`: Amount of grains.
#' - `yeast`: Amount of yeast.
#' - `water`: Amount of water.
#' - `salt`: Amount of salt.
#'
#' @source Not available.
"ingredients"
