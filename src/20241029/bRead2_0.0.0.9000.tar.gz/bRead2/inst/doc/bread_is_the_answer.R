## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(bRead2)

## ----show-ingredients---------------------------------------------------------
ingredients

## ----use-bRead2-to-make-some-bRead2-------------------------------------------
# Prepare the ingredients
ingredients_for_bRead2 <- ingredients[1,]
# Make the bRead2
make_bread(grains = ingredients_for_bRead2$grains,
           water = ingredients_for_bRead2$water,
           salt = ingredients_for_bRead2$salt,
           yeast = ingredients_for_bRead2$yeast)

## ----use-bRead2-to-make-some-focaccia-----------------------------------------
# Prepare the ingredients
ingredients_for_focaccia <- ingredients[2,]
# Make the focaccia
make_focaccia(grains = ingredients_for_focaccia$grain,
              water = ingredients_for_focaccia$water,
              salt = ingredients_for_focaccia$salt,
              yeast = ingredients_for_focaccia$yeast)

