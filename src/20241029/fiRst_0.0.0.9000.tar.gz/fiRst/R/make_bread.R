#' Make bread
#'
#' @param grains Amount of grains.
#' @param yeast Amount of yeast.
#' @param water Amount of water.
#' @param salt Amount of salt.
#'
#' @return Amount of bread.
#' @export
#'
#' @examples
#' make_bread(
#'   grains = 1,
#'   yeast = 2,
#'   water = 3,
#'   salt = 4
#' )
make_bread <- function(grains, yeast, water, salt) {
  # Code to generate `bread`.
  # The code here can be easy (easy bread recipes do exist)
  # or quite complex (complex bread recipes do exist too)
  bread <- grains + yeast + water + salt
  return(bread)
}
