#' Clean data
#'
#' Filter data by issues, occurrence status and coordinate uncertainty.
#'
#' @param df A data.frame. Following columns MUST be present:
#' - `issue`
#' - `occurrenceStatus`
#' - `coordinateUncertaintyInMeters`
#' @param max_coord_uncertain: A number indicating the maximum
#'   `coordinateUncertaintyInMeters` value allowed. Occurrences with
#'   `coordinateUncertaintyInMeters` equal or higher are discarded. Default:
#'   `1000`.
#' @param issues_to_discard A vector with issues (characters). Occurrences with
#'   one or more of these issues are discarded.
#'   Default: `c("ZERO_COORDINATE", "COORDINATE_OUT_OF_RANGE", "COORDINATE_INVALID", "COUNTRY_COORDINATE_MISMATCH")`
#' @param occurrenceStatus_to_discard A vector with occurrence status values
#'   (characters). Occurrences with one of these occurrence statuses are
#'   discarded. Default: `c("absent","excluded")`
#'
#' @importFrom dplyr %>%
#' @return A data.frame. Same columns as input `df`.
#' @export
#'
#' @examples
#' my_data <- dplyr::tibble(
#'   occID = c(1, 2, 3, 4, 5),
#'   issue = c("ZERO_COORDINATE", NA, NA, NA, NA),
#'   occurrenceStatus = c("present", "doubful", "absent", "present", "present"),
#'   coordinateUncertaintyInMeters = c(50, 1500, 100, 50, 30)
#' )
#' my_data
#'
#' # use default values
#' clean_data(my_data)
#'
#' # use non-default values
#' clean_data(
#'   my_data,
#'   max_coord_uncertain = 40
#' )
clean_data <- function(
    df,
    max_coord_uncertain = 1000,
    issues_to_discard = c("ZERO_COORDINATE",
                          "COORDINATE_OUT_OF_RANGE",
                          "COORDINATE_INVALID",
                          "COUNTRY_COORDINATE_MISMATCH"),
    occurrenceStatus_to_discard = c("absent","excluded")) {
  cleaned_df <-
    df %>%
    dplyr::filter(coordinateUncertaintyInMeters < max_coord_uncertain |
             is.na(coordinateUncertaintyInMeters)) %>%
    dplyr::filter(!issue %in% issues_to_discard) %>%
    dplyr::filter(!occurrenceStatus %in% occurrenceStatus_to_discard)
  return(cleaned_df)
}
