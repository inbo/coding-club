#' Plot the distribution of cells over the number of observations and individuals over the
#' cells
#'
#' The function generates an histogram of the cells distribution based on number
#' of observations and number of individuals.
#'
#' @param df A data.frame. Following columns MUST be present:
#' - `n_observations`: number of observations
#' - `n_individuals`: number of individuals
#' @param bin_width A number indicating the width of the bins of the histogram.
#'
#' @importFrom dplyr %>%
#'
#' @return A ggplot2 histogram
#' @export
#'
#' @examples
#' my_data <- dplyr::tibble(
#'   cell_code = c(
#'     "01x005E63N-9",
#'     "01x005E63N-8",
#'     "01x005E64N20",
#'     "01x005E21N23",
#'     "01x005E19N24",
#'     "01x005E19N25"
#'   ),
#'   n_observations = c(4, 2, 6, 1, 20, 2),
#'   n_individuals = c(6, 31, 12, 1, 25, 4)
#' )
#' my_data
#'
#' # use default width bin value (5)
#' plot_distr_cells(my_data)
#'
#' # use non-default value
#' plot_distr_cells(my_data, bin_width = 15)
plot_distr_cells <- function(df, bin_width = 5) {

  #assertions using assertthat package are more customizable
  assertthat::assert_that(
    "n_observations" %in% names(df),
    msg = "Column `n_observations` not found."
  )
  assertthat::assert_that(
    "n_individuals" %in% names(df),
    msg = "Column `n_individuals` not found."
  )

  df <-
    df %>%
    tidyr::pivot_longer(cols = c(n_observations, n_individuals),
                        values_to = "n",
                        names_to = "indicator",
                        names_pattern = "n_?(.*)"
    )

  p <- ggplot2::ggplot(df) +
    ggplot2::geom_histogram(ggplot2::aes(x = n, fill = indicator),
                   position = "dodge",
                   binwidth = bin_width) +
    ggplot2::xlab(sprintf("n (binwidth: %s)", bin_width)) +
    ggplot2::ggtitle(
      label = "Grid cells distribution"
    )
  return(p)
}
