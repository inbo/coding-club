#' Calculate the number of observations and individuals per grid cell
#'
#' Summarizing function to calculate both the number of observations and
#' individuals per grid cell.
#'
#' @param df A data.frame. The following columns MUST be present:
#' - `cell_code`: a character identifying the grid cell as returned by function `calc_grid_cell`.
#' - `individualCount`: Number of individuals linked to the occurrence.
#'
#' @importFrom dplyr %>%
#' @return A data.frame with the following columns:
#' - `cell_code`: grid cell identifier (character).
#' - `n_observations`: Number of observations.
#' - `n_individuals`: Number of individuals, i.e. the sum of `individualCount`.
#' @export
#'
#' @examples
#' my_data <- dplyr::tibble(
#'   occiD = c(1, 2, 3, 4, 5),
#'   cell_code = c(
#'     "01x005E32N10",
#'     "01x005E32N10",
#'     "01x005E32N10",
#'     "01x005E31N-5",
#'     "01x005E31N-5"),
#'   individualCount = c(2, 5, NA, 1, 2)
#' )
#' my_data
#'
#' calc_n_obs_ind(my_data)
calc_n_obs_ind  <- function(df) {

  # for basic checks you can use `stopifnot()` R base function.
  stopifnot("cell_code" %in% colnames(df))
  stopifnot("individualCount" %in% colnames(df))

  df <-
    df %>%
    group_by(cell_code) %>%
    summarise(n_observations = n(), # number of observations (rows)
              n_individuals = sum(individualCount) # number of individuals
    )

  return(df)
}
