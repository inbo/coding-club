#' Get observations
#'
#' @param species A character
#' @param year A number
#' @param root_folder A character with path
#'
#' @return A data.frame
#' @export
#'
#' @examples
#' \dontrun{
#' get_obs(species = "Harmonia axyridis", year = 2011)
#' }
get_obs <- function(species, year, root_folder = "./") {

  # species and year MUST be unique and of right type, otherwise arise error
  assertthat::is.string(species)
  assertthat::is.number(year)

  # Set scientific name to lowercase
  species <- tolower(species)
  # Replace spaces with underscores
  species <- stringr::str_replace_all(
    species,
    pattern = " ",
    replacement = "_"
  )

  # Compose filename
  file_name <- paste0("20230926_", species, "_", year, ".txt")

  # Read file using the specified root folder
  obs <- readr::read_tsv(paste0(root_folder, file_name))
  return(obs)
}
