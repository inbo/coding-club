#' Add the grid cell identifier
#'
#' Add the grid cell identifier each occurrence belongs to based on lat/lon
#' values. The grid size can be defined. The grid cell identifier is composed as follows:
#' - `x_size` without dot, e.g. `"01"` for `x_size` = `0.1`.
#' - `"x"` symbol.
#' - `y_size` without dot, e.g. `"005"` for `y_size` = `0.05`.
#' - `"E"`, stays for East.
#' - the value of `floor(decimalLongitude / x_size)` as character.
#' - `"N"`, stays for North.
#' - the value of `floor(decimalLatitude / y_size)` as character.
#'
#' @param df A data.frame. The following columns MUST be present:
#' - `decimalLongitude`
#' - `decimalLatitude`
#' @param x_size x-size of the grid cells as longitude values. Default:`0.1`.
#' @param y_size y-size of the grid cells as latitude values. Default: `0.05`.
#'
#' @importFrom dplyr %>%
#' @return A data.frame. Same rows as input `df`. Column `cell_code` added.
#' @export
#'
#' @examples
#' my_data <- dplyr::tibble(
#'   occID = c(1, 2, 3),
#'   decimalLongitude = c(32.45, 0.57, -20.35),
#'   decimalLatitude = c(10.4, -4.2, 0.2)
#' )
#' my_data
#'
#' # use default values
#' calc_grid_cell(my_data)
#'
#' # use other values
#' calc_grid_cell(my_data, x_size = 1, y_size = 1)
calc_grid_cell <- function(df,
                           x_size = 0.1,
                           y_size = 0.05) {
  df <-
    df %>%
    dplyr::mutate(cell_code = paste0(
      "01x005",
      "E", floor(decimalLongitude / x_size),
      "N", floor(decimalLatitude / y_size)
      )
    )
  return(df)
}
