Usage example:


call dump_grid_landsea.bat de Germany Germany 10
where: 
%1 short name used in file
%2 name used in gaul (field adm0_name)
%3 name used in eez (field country)
%4 resolution (1, 10, 100)

call dump_grid_land.bat at Austria 10
%1 short name used in file
%2 name used in gaul (field adm0_name)
%3 resolution (1, 10, 100)
