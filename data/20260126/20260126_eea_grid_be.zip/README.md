# EEA reference grid for Belgium (10km), May 2013

The grid is based on proposal at the 1st European Workshop on Reference Grids in 2003 and later INSPIRE geographical grid systems. The sample grid available here is part of a set of three polygon grids in 1, 10 and 100 kilometres. The grids cover at least country borders and, where applicable, marine Exclusive Economic Zones v7.0, http://www.marineregions.org. Note that the extent of the grid into the marine area does not reflect the extent of the territorial waters.https://sdi.eea.europa.eu/geonetwork/srv/api/records/a25da98d-0df0-420a-bc27-1c486376c72bf


[More information](https://sdi.eea.europa.eu/catalogue/srv/api/records/a25da98d-0df0-420a-bc27-1c486376c72bf)
    